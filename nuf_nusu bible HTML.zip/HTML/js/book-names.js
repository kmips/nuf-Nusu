var books = [
  { name: "Ma-Thi", ref: "" },
  { name: "Ma-Khoc", ref: "02-MRK-001.html" },
  { name: "JHN", ref: "03-JHN-001.html" },
  { name: "Cri-Khoe", ref: "04-ACT-001.html" },
  { name: "1the-Sa-Lo-Ni-Ya", ref: "05-1TH-001.html" },
  { name: "2the-Sa-Lo-Ni-Ya", ref: "06-2TH-001.html" },
  { name: "Thix-Toq", ref: "07-TIT-001.html" },
  { name: "Phi-Li-Mivx", ref: "08-PHM-001.html" },
];
